﻿using EjercicioEmpresa;

Operario operario_1 = new("Ricardo", "Retiro", "Empleado", "Operario");
Operario operario_2 = new("Pablo", "Retiro", "Empleado", "Operario");
Operario operario_3 = new("Pepito", "Retiro", "Empleado", "Operario");
JefeSeccion jefeSeccion_1 = new("Pedro", "Cordoba", "Empleado", "Jefe de seccion");

jefeSeccion_1.AsignarOperario(operario_1);
jefeSeccion_1.AsignarOperario(operario_2);
jefeSeccion_1.AsignarOperario(operario_3);

jefeSeccion_1.Informar();