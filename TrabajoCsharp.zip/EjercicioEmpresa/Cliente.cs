namespace EjercicioEmpresa;
using ConsoleTables;

public class Cliente : Persona
{
    public double credito { get;}
    public Cliente(string nombre, string domicilio, string rol, double credito) : base(nombre, domicilio, rol)
    {
        Validacion.validarCliente(rol, "Error, no es un cliente");
        Validacion.validarCredito(credito, "Error, el credito no puede ser mayor a 1000 o menor a cero");
        this.credito = credito;
    }
    public override void Informar()
    {
        var table = new ConsoleTable("Nombre", "Domicilio", "Rol", "Credito");
        table.AddRow(nombre, domicilio, rol, credito);
        table.Write();
    }
}