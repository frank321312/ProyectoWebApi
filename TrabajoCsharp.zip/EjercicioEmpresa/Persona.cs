﻿namespace EjercicioEmpresa;
using ConsoleTables;

public abstract class Persona
{
    public string nombre { get; set; }
    public string domicilio { get; set; }
    public string rol { get; set; }
    public Persona(string nombre, string domicilio, string rol)
    {
        this.nombre = nombre;
        this.domicilio = domicilio;
        this.rol = rol;
    }
    public abstract void Informar();
}