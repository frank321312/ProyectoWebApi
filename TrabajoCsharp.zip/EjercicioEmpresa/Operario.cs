namespace EjercicioEmpresa;
using ConsoleTables;

public class Operario : Persona
{
    public double sueldoOperario { get;}
    public string rolEmpresa { get; private set;}
    public Operario(string nombre, string domicilio, string rol, string rolEmpresa) : base(nombre, domicilio, rol)
    {
        Validacion.validarEmpleado(rol, "Error, no es un empleado");
        Validacion.validarOperario(rolEmpresa, "Error, no es un operario");
        this.sueldoOperario = 100000;
        this.rolEmpresa = rolEmpresa;
    }
    public override void Informar()
    {
        var table = new ConsoleTable("Nombre", "Domicilio", "Rol", "Sueldo", "Rol empresa");
        table.AddRow(nombre, domicilio, rol, sueldoOperario, rolEmpresa);
        table.Write();
    }
}