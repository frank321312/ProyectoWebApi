namespace EjercicioEmpresa;

public static class Validacion
{
    public static void validarCliente(string n, string mensajeErr)
    {
        if (n != "Cliente" && n != "cliente") throw new Exception(mensajeErr);
    }
    public static void validarEmpleado(string n, string mensajeErr)
    {
        if (n != "Empleado" && n != "empleado") throw new Exception(mensajeErr);
    }
    public static void validarJefeSeccion(string n, string mensajeErr)
    {
        if (n != "Jefe de seccion" && n != "jefe de seccion") throw new Exception(mensajeErr);
    }
    public static void validarOperario(string n, string mensajeErr)
    {
        if (n != "Operario" && n != "operario") throw new Exception(mensajeErr);
    }
    public static void validarCredito(double credito, string mensajeErr)
    {
        if (credito > 1000 || credito < 0) throw new Exception(mensajeErr);
    }
}