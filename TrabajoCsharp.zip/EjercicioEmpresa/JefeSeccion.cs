namespace EjercicioEmpresa;
using ConsoleTables;

public class JefeSeccion : Persona
{
    public double sueldoJefe { get; set;}
    public string rolEmpresa { get; private set;}
    List<Operario> listOperario;
    public JefeSeccion(string nombre, string domicilio, string rol, string rolEmpresa) : base(nombre, domicilio, rol)
    {
        this.rolEmpresa = rolEmpresa;
        sueldoJefe = 80000;
        this.listOperario = new List<Operario>();
    }
    public void AsignarOperario(Operario operario)
    {
        listOperario.Add(operario);
        sueldoJefe += 5000;
    }
    public override void Informar()
    {
        var table = new ConsoleTable("Nombre", "Domicilio", "Rol", "Sueldo", "Rol empresa", "Operario");
        sueldoJefe = 80000;
        foreach (var operario in listOperario)
        {
            sueldoJefe += 5000;
            table.AddRow(nombre, domicilio, rol, sueldoJefe, rolEmpresa, operario.nombre);
        }
        table.Write();
        var table2 = new ConsoleTable("Nombre", "Domicilio", "Rol", "Sueldo", "Rol empresa");
        table2.AddRow(nombre, domicilio, rol, sueldoJefe, rolEmpresa);
        table2.Write();
    }
}
