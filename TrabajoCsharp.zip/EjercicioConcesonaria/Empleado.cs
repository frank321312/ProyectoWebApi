namespace EjercicioConcesonaria;
using ConsoleTables;
public abstract class Empleado
{
    public int id { get; set; }
    public string nombre { get; set; }
    public string apellido { get; set; }
    public string categoria { get; set; }
    public double montoBasico { get; set; }
    public int cantidadVenta { get; set; }
    public int bono { get; set; }
    public DateTime fechaIngreso { get; set; }
    public DateTime fechaActual { get; set; }
    public Empleado(string nombre, string apellido, string categoria,int cantidadVenta, DateTime fechaImgreso, DateTime fechaActual)
    {
        this.nombre = nombre;  
        this.apellido = apellido;
        this.categoria = categoria; 
        this.cantidadVenta = cantidadVenta;
        this.fechaIngreso = fechaImgreso;
        this.fechaActual = fechaActual;
    }
    public double CalcularSueldo() => montoBasico + (bono * cantidadVenta);
    public void informar()
    {
        var table = new ConsoleTable("Nombre", "Apellido", "Categoria", "Id", "Monto basico", "Bono venta", "Autos vendidos", "Suledo total");
        table.AddRow(nombre, apellido, categoria, id, montoBasico, bono, cantidadVenta, CalcularSueldo());
        table.Write();
    }
}
