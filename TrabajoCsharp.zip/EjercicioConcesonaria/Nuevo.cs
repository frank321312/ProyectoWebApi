namespace EjercicioConcesonaria;
public class Nuevo : Empleado
{
    public Nuevo(string nombre, string apellido, string categoria, int cantidadVenta, DateTime fechaImgreso, DateTime fechaActual) : base(nombre, apellido, categoria, cantidadVenta, fechaImgreso, fechaActual)
    {
        Validacioneses.validarNuevo(fechaIngreso, fechaActual, "Error,no es nuevo");
        id += 1;
        montoBasico = 10000;
        bono = 5000;
    }
}
