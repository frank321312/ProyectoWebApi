namespace EjercicioConcesonaria;

public static class Validacioneses
{
    public static void validarNuevo(DateTime fecha_1, DateTime fecha_2, string mensajeErr)
    {
        TimeSpan diferencia = fecha_2 - fecha_1;
        if (diferencia.TotalDays > 364) throw new Exception(mensajeErr);
    }
    public static void validarJunior(DateTime fecha_1, DateTime fecha_2, string mensajeErr)
    {
        TimeSpan diferencia = fecha_2 - fecha_1;
        if (diferencia.TotalDays < 365 || diferencia.TotalDays > 1095) throw new Exception(mensajeErr);
    }
    public static void validarSenior(DateTime fecha_1, DateTime fecha_2, string mensajeErr)
    {
        TimeSpan diferencia = fecha_2 - fecha_1;
        if (diferencia.TotalDays <= 1095) throw new Exception(mensajeErr);
    }
}
