﻿using EjercicioConcesonaria;

Nuevo nuevo_1 = new("Pepito", "Perez", "Nuevo", 10, new DateTime(2022, 07, 19), new DateTime(2023, 07, 19));

nuevo_1.informar();

// DateTime fecha1 = new DateTime(2023, 9, 25);
//         DateTime fecha2 = new DateTime(2023, 9, 20);

//         // Restar las fechas
//         TimeSpan diferencia = fecha1 - fecha2;

//         // Mostrar la diferencia en días
//         int diferenciaEnDias = diferencia.Days;
//         Console.WriteLine($"La diferencia entre las fechas es de {diferenciaEnDias} días.");